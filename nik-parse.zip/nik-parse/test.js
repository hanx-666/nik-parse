const nik = "3204110609970001";
nikParse(nik, function(result) {
	console.log(result);
});
